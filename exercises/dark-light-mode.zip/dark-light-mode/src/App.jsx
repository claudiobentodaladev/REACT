import { useContext } from 'react'
import { ThemeContext } from './context/Theme.context'
import { LuSunMoon as SunMoon } from 'react-icons/lu'
import { BtnMode } from './components/BtnMode.style'
import { WrapperStyle } from './components/Wrapper.style'
export default function App() {

    const { swicthTheme } = useContext(ThemeContext)

    return (
        <WrapperStyle>
            <BtnMode onClick={swicthTheme} >
                <span>
                    <SunMoon />
                </span>
            </BtnMode>
        </WrapperStyle>
    )
}