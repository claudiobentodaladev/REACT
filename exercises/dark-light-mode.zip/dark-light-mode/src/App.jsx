import { useState } from 'react'
import './App.css'
export default function App() {

    
    const [dark, setDark] = useState( ()=> false )
    localStorage.setItem('dark', dark)

    function mode() {
        setDark(modeDark => !modeDark) 
        document.querySelector('body').classList.toggle('dark')
    }

    return(
        <>
            <h1>dark and ligth mode</h1>
            <button onClick={mode}>theme</button>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Blanditiis consequatur sunt earum debitis perferendis illum aliquam vitae tempore exercitationem esse, amet facere est expedita sit sed. Tempora nobis aut ea.
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem minus dolore odio tenetur, necessitatibus sed natus ut nulla facilis esse culpa aut? Ullam itaque unde, temporibus repellat iste expedita culpa.
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quaerat voluptatum maiores quae est soluta, sequi libero. Mollitia odit harum, veniam aspernatur, similique est rerum assumenda quia eum eligendi optio repudiandae!
            </p>
        </>
    )
}