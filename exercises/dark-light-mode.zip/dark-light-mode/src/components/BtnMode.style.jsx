import { useContext } from 'react'
import { styled } from 'styled-components'
import { ThemeContext } from '../context/Theme.context'

export const BtnMode = styled.button`
    &{
        height: 35px;
        width: 90px;
        border-radius: 30px;
        background: none;
        border: 2px solid black;
        padding: 0 1px;

        display: flex;
        align-items: center;
        overflow: hidden;
        
        justify-content: ${() => {
        const { dark } = useContext(ThemeContext)
        if (dark) {
            return 'end'
        } else {
            return 'start'
        }
    }};

        background-color: ${() => {
        const { dark } = useContext(ThemeContext)
        if (dark) {
            return '#3bdfdf'
        } else {
            return '#f0f0f0'
        }
    }};
    }
    &:hover{
        cursor: pointer;
    }
    & span{
        &{
            border: 1px solid black;
            height: 25px;
            width: 25px;
            border-radius: 50%;
            display: grid;
            place-content: center;

            background-color: ${() => {
        const { dark } = useContext(ThemeContext)
        if (dark) {
            return '#000000'
        } else {
            return 'white'
        }
    }};

            color: ${() => {
        const { dark } = useContext(ThemeContext)
        if (dark) {
            return '#3bdfdf'
        } else {
            return 'initial'
        }
    }};
        }
    }
`