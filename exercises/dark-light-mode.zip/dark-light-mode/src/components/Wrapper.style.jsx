import { useContext } from 'react'
import { styled } from 'styled-components'
import { ThemeContext } from '../context/Theme.context'

export const WrapperStyle = styled.main`
    &{
        height: 100vh;
        display: grid;
        place-content: center;

        background-color: ${() => {
        const { dark } = useContext(ThemeContext)
        if (dark) {
            return '#212121'
        } else {
            return 'white'
        }
    }};
    }
`