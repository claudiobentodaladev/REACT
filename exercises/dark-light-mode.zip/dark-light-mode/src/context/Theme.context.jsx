import { createContext, useEffect, useState } from "react"

export const ThemeContext = createContext()

export function ThemeProvider({ children }) {

    const [dark, setdark] = useState(() => JSON.parse(localStorage.getItem('theme')))

    useEffect(() => { 
        setdark(() => JSON.parse(localStorage.getItem('theme')))
    }, [])

    useEffect(() => {
        localStorage.setItem('theme', JSON.stringify(dark))
    }, [dark])

    function swicthTheme() {
        setdark(current => !current)
    }

    return (
        <ThemeContext.Provider value={{ dark, swicthTheme }} >
            {children}
        </ThemeContext.Provider>
    )
}