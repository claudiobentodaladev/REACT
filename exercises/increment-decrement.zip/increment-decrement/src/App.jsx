import { useState } from "react"
import { LuRefreshCw as Reset } from 'react-icons/lu'
import { WapperStyle as Main } from "./components/Wrapper.style"

export default function App() {

    const [number, setNumber] = useState(() => 0)

    //-------------INCREMENT---------------------------------------------
    const increment = () => setNumber(currentNumber => currentNumber + 1)

    //------------DECREMENT----------------------------------------------
    const decrement = () => setNumber(currentNumber => currentNumber - 1)

    //---------RESET----------------------------------------------------
    const reset = () => setNumber(() => 0)

    return (
        <Main value={number} >
            <button className="increment" onClick={increment}>+</button>

            <p>{number}</p>

            <button className="decrement" onClick={decrement}>-</button>

            <button className="reset" onClick={reset}><Reset /></button>
        </Main>
    )
}