import { styled } from 'styled-components'

function stateNumber({ value }) {
    if (value === 0) {
        return 'white'
    } else if (value > 0) {
        return 'green'
    } else if (value < 0) {
        return '#e41212'
    }
}

export const WapperStyle = styled.section`
    &{
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 15px;
    }
    *:hover{
        cursor: pointer;
    }
    & p{
        color: ${stateNumber};
    }
    & button{
        &{
            background-color: #303030;
            border: none;
            font-size: 20px;
            font-weight: bold;
            width: 50px;
            border-radius: 50px;
            display: grid;
            place-content: center;
            height: 25px;
            transform: all .5s;
        }
        &:hover{
            background-color: initial;
            border: 2px solid #353535;
        }
        &.increment{
            color: #00ff00;
        }
        &.decrement,&.reset{
            color: #ff0000;
        }
    }
`