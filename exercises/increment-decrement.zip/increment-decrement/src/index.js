import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import { GlobalStyle } from './components/Global.style'

createRoot(document.querySelector('#root')).render(
    <StrictMode>
        <GlobalStyle />
        <App />
    </StrictMode>
)