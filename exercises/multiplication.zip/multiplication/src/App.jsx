import { useRef, useState } from 'react'
import Multiplicad from './components/Multiplicad'
import './App.css'
export default function App() {

    const inputRef = useRef()
    const [value, setValue] = useState( ()=> 1 )

    function getValueInput(numb) {
        if (numb === '') {
            numb = 0
        } else if (numb < 0) {
            numb *= -1
        }
        setValue( ()=> numb )
    }

    return(
        <>
            <h1>multiplication</h1>
            <input type="number" id="imulNumb" ref={inputRef} onChange={()=> getValueInput(inputRef.current.value) } />
            <Multiplicad mulNumb={value}/>
        </>
    )
}