export default function Multiplicad(props) {

    let product = []
    function multiplication() {
        for (let index = 1; index < 11; index++) {
            product.push(`${props.mulNumb} X ${index} = ${index * props.mulNumb}`)
        }
        return product
    }

    return (
        <>
            {multiplication().map(resulted => {
                let randomID = resulted + 1 + Math.random()
                return <p key={randomID} >{resulted}</p>
            })}
        </>
    )
}