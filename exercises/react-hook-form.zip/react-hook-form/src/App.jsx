import { Form } from "./components/Form.style";
import { useForm } from 'react-hook-form'
// Use form section on component
export function App() {

    const { register, handleSubmit, formState: { errors } } = useForm()

    console.log('render')

    function onSubmit(data) {
        alert(JSON.stringify(data))
    }

    return (
        <Form>
            <div>
                <label htmlFor='iname'>name</label>
                <input id='iname' type='text' placeholder='your name' {...register('name', { required: true })} />
                {errors?.name?.type === 'required' && <p>name is {errors?.name?.type} </p>}
            </div>
            <div>
                <label htmlFor='iemail'>email</label>
                <input id='iemail' type='email' placeholder='your email' {...register('email', { required: true })} />
                {errors?.email?.type === 'required' && <p>email is {errors?.email?.type} </p>}
            </div>
            <div>
                <label htmlFor='ijob'>job</label>
                <select id="ijob" {...register('job', { validate: (value) => value !== 'none' })} >
                    <option value="none">select your job...</option>
                    <option value="softDev">sofware developer</option>
                    <option value="webDev">Web developer</option>
                    <option value="devOp">DevOp</option>
                </select>
                {errors?.job?.type === 'validate' && <p>job is required</p>}
            </div>
            <div>
                <label htmlFor='ipassword'>password</label>
                <input id='ipassword' type='password' placeholder='password' {...register('password', { required: true, minLength: 7 })} />
                {errors?.password?.type === 'minLength' && <p>password must have at leat 7 character</p>}
                {errors?.password?.type === 'required' && <p>password is {errors?.password?.type}</p>}
            </div>
            <button onClick={() => handleSubmit(onSubmit)()}>create account</button>
        </Form>
    )
}