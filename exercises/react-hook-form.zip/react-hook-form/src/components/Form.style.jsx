import { styled } from 'styled-components'

export const Form = styled.section`
    &{
        display: flex;
        flex-flow: column nowrap;
        gap: 10px;
    }
    & input, select, button{
        width: 350px;
        height: 30px;
        font-size: 16px;
        border-radius: 3px;
        border: 0;
        color: white;
    }
    & > div{
        &{
            display: flex;
            flex-flow: column nowrap;
            gap: 5px;
        }
        & label{
            text-transform: capitalize;
            color: white;
        }
        & input,select{
            background-color: #36373a;
        }
        & p{
            color: #c40202;
        }
        & input{
            &{
                transition: all .5s;
                padding: 10px 5px;
            }
            &:focus-within{
                &{
                    outline: none;
                }
                &::placeholder{
                    color: white;
                }
            }
        }
    }
    & button{
        &{
            text-transform: capitalize;
            background-color: #188686;
        }
        &:hover{
            cursor: pointer;
        }
    }
`