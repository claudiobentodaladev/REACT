import React from 'react'
import { createRoot } from 'react-dom/client'
import { GlobalStyle } from './components/Global.style'
import { App } from './App'

createRoot(document.querySelector('#root')).render(
    <React.StrictMode>
        <GlobalStyle />
        <App />
    </React.StrictMode>
)