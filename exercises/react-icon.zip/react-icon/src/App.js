import {FaGithub, FaInstagram, FaLinkedin} from 'react-icons/fa'

export default function App() {
    
    const standard = {
        color: 'purple',
        size: 50
    }

    return(
        <>
            <FaGithub size={standard.size} color={standard.color}/>
            <FaInstagram size={standard.size} color={standard.color}/>
            <FaLinkedin size={standard.size} color={standard.color}/>
        </>
    )
}