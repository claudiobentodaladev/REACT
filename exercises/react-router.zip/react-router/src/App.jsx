import './App.css'
import { Outlet } from 'react-router-dom'
import NavBar from './components/NavBar'
export default function App() {

    const styles = {
        border: '2px dotted #3bdfdf',
        padding: '10px'
    }

    return(
        <>
            <header style={styles}>
                <p>header</p>
                <NavBar />
            </header>
            <Outlet />
            <footer style={styles}>footer</footer>
        </>
    )
}