import React from "react"
import { createRoot } from 'react-dom/client'
import { createBrowserRouter, RouterProvider, Navigate } from 'react-router-dom'
import App from "./App"

import Home from "./routes/Home"
import Contact from "./routes/Contact"
import Error404 from "./routes/Error404"
import Detail from "./routes/Detail"

const router = createBrowserRouter([
    {
        path: '/',
        element: <App />,
        errorElement: <Error404 />,
        children:
            [
                {
                    path: '/',
                    element: <Home />
                },
                {
                    path: 'contact',
                    element: <Contact />
                },
                {
                    path: '/contact/:id',
                    element: <Detail/>
                },
                {
                    path: 'oldcontact',
                    element: <Navigate to='/contact' />
                }
            ]
    }
])

createRoot(window.document.querySelector('#root')).render(
    <RouterProvider router={router} />
)