import { Link } from 'react-router-dom'
import './../App.css'
export default function Contact() {
    return(
        <main>
            <h1>Contact</h1>
            <div>
                <Link to='/contact/1'>detail_1</Link>
                <Link to='/contact/2'>detail_2</Link>
                <Link to='/contact/3'>detail_3</Link>
            </div>
        </main>
    )
}