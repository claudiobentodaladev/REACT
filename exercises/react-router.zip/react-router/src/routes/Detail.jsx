import { useNavigate } from 'react-router-dom'
import { useParams } from 'react-router-dom'
import './../App.css'

export default function Detail() {
    
    const {id} = useParams()

    const navigate = useNavigate()

    function handleForm() {
        console.log('SENT!')
        navigate('/')
    }
    
    return(
        <main>
            <h1>detail contact</h1>
            <p>This is page <strong>{id}</strong></p>
            <div>
                <button onClick={handleForm}>Send sms</button>
            </div>
        </main>
    )
}