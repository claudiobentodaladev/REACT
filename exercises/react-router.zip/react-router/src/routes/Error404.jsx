import './../App.css'
export default function Error404() {
    return(
        <main>
            <h1>Page not found!</h1>
            <p>ERROR 404</p>
        </main>
    )
}