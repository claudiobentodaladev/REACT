import react from "react"

export default function Comp(props) {

    let styles = {
        color: 'red',
        padding: '10px',
        borderRadius: '15px',
        backgroundColor: '#212121'
    }

    return(
        <>
            <h1 style={styles} className="title">title {props.title}  </h1>
        </>
    )
}