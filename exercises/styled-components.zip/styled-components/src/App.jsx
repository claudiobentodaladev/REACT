import { Wrapper } from './components/Wrapper.style'
import { Button } from "./components/Button.style"

export default function App() {
    return (
        <Wrapper>
            <Button>one</Button>
            <Button back='pink'>two</Button>
            <span>click on</span>
        </Wrapper>
    )
}