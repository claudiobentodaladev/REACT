import styled from 'styled-components'
import { theme } from './Theme.style'

function backColor({ back }) {
    return back ? back : theme.colors.primary
}
export const Button = styled.button`
    &{
        width: ${theme.size.primary.width};
        height: ${theme.size.primary.heigth};
        background-color: ${backColor};
    }
    &:hover{
        background-color: ${theme.colors.scondary};
    }
`