export const theme = {
    colors: {
        primary: 'red',
        scondary: 'blue'
    },
    size: {
        primary: {
            width: '300px',
            heigth: '100px'
        },
        secondary: {
            width: '600px',
            heigth: '200px'
        }
    }
}