import styled from "styled-components";

export const Wrapper = styled.main`
    &{
        background-color: gray;
    }
    & span{
        &{
            color: blue;
            text-decoration: none;
        }
        &:hover{
            text-decoration: underline;
        }
    }

`