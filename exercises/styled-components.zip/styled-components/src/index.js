import React from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import { GlobalStyle } from './components/Global.style'
import { ThemeProvider } from 'styled-components'
import { theme } from './components/Theme.style'

createRoot(document.querySelector('#root')).render(
    <React.StrictMode>
        <ThemeProvider theme={theme}>
            <GlobalStyle />
            <App />
        </ThemeProvider>
    </React.StrictMode>
)