import { useEffect, useRef, useState } from 'react';
import { randomKey } from './utils/randomKey';
import './App.css'
import Item from "./components/Item";
import { LuRefreshCw as Refresh } from 'react-icons/lu';


export default function App() {

    const [listItem, setListItem] = useState(() => [{ item: '', checked: undefined, id: '' }])
    const [newItem, setNewItem] = useState(() => '')
    const inputRef = useRef()

    //--------------LOCAL STORAGE-----------------------------
    useEffect(() => {
        if (localStorage.getItem('itens') !== null) {
            setListItem(() => JSON.parse(localStorage.getItem('itens')))
        }
    }, [])
    useEffect(() => {
        localStorage.setItem('itens', JSON.stringify(listItem))
    }, [listItem])

    //--------------GET ITEM-----------------------------
    const getItem = (item) => setNewItem(() => item)

    //--------------ADD ITEM-----------------------------
    function addItem() {
        const sameItem = listItem.find(oneOf => oneOf.item === newItem)
        if (typeof sameItem === 'undefined') {
            if (inputRef.current.value !== '') {
                setListItem([...listItem, { item: newItem, checked: false, id: randomKey() }])
            }
        }
        inputRef.current.value = ''
    }
    function enterAddItem(event) {
        if (event.key === 'Enter') {
            addItem()
        }
    }

    //--------------REFRESH LIST ITEM-----------------------------
    function refreshListItem() {
        setListItem(() => [])
        console.clear()
        inputRef.current.value = ''
    }

    //--------------CHECK ITEM-----------------------------
    function checkItem(itemChecked) {
        const filteredList = listItem.filter(allItem => allItem.id !== itemChecked.id)
        const checking = { item: itemChecked.item, checked: !itemChecked.checked, id: itemChecked.id }
        if (itemChecked.checked) {
            filteredList.unshift(checking)
        } else {
            filteredList.push(checking)
        }
        setListItem(() => filteredList)
    }

    //--------------REMOVE ITEM-----------------------------
    function removeItem(itemRemoved) {
        const filteredList = listItem.filter(allItem => allItem.id !== itemRemoved)
        setListItem(() => filteredList)
    }

    return (
        <main>
            <h1>to do list</h1>
            <div className="TextBox">
                <input ref={inputRef} onChange={input => getItem(input.target.value)} onKeyUp={enterAddItem} maxLength={30} type="text" placeholder="Add a new item..." />
                <button onClick={addItem} className='add'>add</button>
                <button onClick={refreshListItem} className='Refresh'><Refresh /></button>
            </div>
            <section>
                <ul>
                    {listItem.map(item => {
                        return <Item key={item.id} item={item} checkItem={checkItem} removeItem={removeItem} />
                    })}
                </ul>
            </section>
        </main>
    )
}