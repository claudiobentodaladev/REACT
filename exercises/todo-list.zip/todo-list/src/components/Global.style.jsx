import { createGlobalStyle } from "styled-components";

export const GlobalStyle = createGlobalStyle`
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: Arial, Helvetica, sans-serif;
    }
    body {
        display: grid;
        justify-content: center;
        height: 100vh;
        background-color: #2c2c2c;
        padding-top: 2em;
    }

    button,
    input {
        & {
            background: transparent;
            border: none;
            display: grid;
            place-content: center;
        }

        &:hover {
            cursor: pointer;
        }
    }
    
`