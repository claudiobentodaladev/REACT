import { ItemStyle } from './Item.style'
import { LuCheck as Check, LuTrash2 as Trash } from 'react-icons/lu'
export default function Item({ item, checkItem, removeItem }) {

    function checkedStyle() {
        if (item.checked) {
            return {
                color: 'gray',
                textDecoration: 'line-through'
            }
        }
    }

    return (
        <ItemStyle>
            <button onClick={() => checkItem(item)} className='check'><Check /></button>

            <p style={checkedStyle()}>{item.item}</p>

            <button onClick={() => removeItem(item.id)} className='trash'><Trash /></button>
        </ItemStyle>
    )
}