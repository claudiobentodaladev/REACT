import styled from "styled-components";
import {ThemeStyle} from './Theme.style'

export const ItemStyle = styled.li`
    & {
        background-color: white;
        height: ${ThemeStyle.box.height};
        width: ${ThemeStyle.box.width};
        padding: ${ThemeStyle.box.padding};
        cursor: ${ThemeStyle.box.cursor};
        display: ${ThemeStyle.box.display};
        justify-content: ${ThemeStyle.box.justifyContent};
        align-items: ${ThemeStyle.box.alignItems};
        gap: ${ThemeStyle.box.gap};
    }

    & p {
        flex-basis: 100%;
        font-size: 15px;
    }

    & button {
        & {
            padding: 2px;
            border-radius: 75%;
        }

        &.check>svg {
            color: green;
        }

        &.trash>svg {
            color: ${ThemeStyle.colors.secondary};
        }
    }
`