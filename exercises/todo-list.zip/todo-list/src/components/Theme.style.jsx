export const ThemeStyle = {
    colors: {
        primary: '#3bdfdf',
        secondary: '#e40a0a'
    },
    box: {
        height: '30px',
        width: '250px',
        padding: '0 5px',
        cursor: 'inherit',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        gap: '5px'
    }
}