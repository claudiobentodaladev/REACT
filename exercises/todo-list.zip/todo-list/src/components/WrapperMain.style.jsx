import { styled } from 'styled-components'
import { ThemeStyle } from './Theme.style'

export const WrapperMain = styled.main`
    & {
        display: flex;
        flex-flow: column nowrap;
        gap: 10px;
        scale: calc( 100% + 30% );
    }

    & h1 {
        color: ${ThemeStyle.colors.primary};
        text-shadow: 3px 2px 1px #0000006c;
        text-align: center;
        text-transform: uppercase;
    }

    & section {
        & ul {
            display: flex;
            flex-flow: column nowrap;
            gap: 7px;
            list-style: none;
        }
    }

    .TextBox {
    & {
        background-color: #161616;
        border-left: 2px solid ${ThemeStyle.colors.primary};
        height: ${ThemeStyle.box.height};
        width: ${ThemeStyle.box.width};
        padding: ${ThemeStyle.box.padding};
        cursor: ${ThemeStyle.box.cursor};
        display: ${ThemeStyle.box.display};
        justify-content: ${ThemeStyle.box.justifyContent};
        align-items: ${ThemeStyle.box.alignItems};
        gap: ${ThemeStyle.box.gap};
    }

    & input {
        & {
            flex-basis: 100%;
            color: white;
        }

        &:hover {
            cursor: text;
        }

        &:focus-within {
            & {
                outline: none;
                transition: .5s;
            }

            &::placeholder {
                color: #979797;
            }
        }
    }

    & button {
        &:hover {
            cursor: pointer;
        }

        &.add {
            color: ${ThemeStyle.colors.primary};
        }

        &.Refresh {
            color: ${ThemeStyle.colors.secondary};
        }
    }

}
`