import React from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import { GlobalStyle } from './components/Global.style'
import { ThemeProvider } from 'styled-components'
import { ThemeStyle } from './components/Theme.style'

createRoot(document.querySelector('#root')).render(
    <React.StrictMode>
        <ThemeProvider theme={ThemeStyle}>
            <GlobalStyle />
            <App />
        </ThemeProvider>
    </React.StrictMode>
)