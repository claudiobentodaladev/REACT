export function randomKey() {
    return Math.random() * 1.3 / 0.4 + (Math.random() + Math.PI)
}