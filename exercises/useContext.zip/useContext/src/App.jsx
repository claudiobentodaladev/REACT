import Comp1 from './components/Comp1'
import Comp2 from './components/Comp2'
import { useContext } from 'react'
import { ThemeContext } from './context/ThemeContext'
import './App.css'
export default function App() {

    const { theme, toggleTheme } = useContext(ThemeContext)

    return (
        <>
            <h1>Hook UseContext</h1>
            <p>The currintly theme is {theme}</p>
            <button onClick={toggleTheme}>change theme</button>
            <div>
                <Comp1 />
                <Comp2 />
            </div>
        </>
    )
}