import { useContext } from "react"
import { ThemeContext } from "../context/ThemeContext"

export default function Comp1() {

    const { theme, toggleTheme } = useContext(ThemeContext)

    return (
        <>
            <div style={{ border: '2px dotted white', margin: '10px 0' }}>
                <h1>Component 1</h1>
                <p>theme: {theme}</p>
                <button onClick={toggleTheme}>change theme</button>
            </div>
        </>
    )
}