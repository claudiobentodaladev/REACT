import { createRoot } from 'react-dom/client'
import { ThemeProvider } from './context/ThemeContext.jsx'
import App from './App.jsx'

createRoot(window.document.querySelector('#root')).render(
    <ThemeProvider>
        <App />
    </ThemeProvider>
)