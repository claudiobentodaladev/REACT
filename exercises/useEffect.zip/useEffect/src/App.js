import {useState, useEffect} from "react"

export default function App() {

    const [value, setValue] = useState( ()=> 10 )

    function change() {
        setValue( currintly => currintly + 1)
    }

    useEffect(()=>{
        console.log('changed')
    },[value])

    return(
        <>
            <h1>react hooks</h1>
            <p>{value}</p>
            <button onClick={change}>change</button>
        </>
    )
}