import { useId } from 'react'
import './App.css'
export default function App() {

    const id = {
        state: useId(),
        likes: useId()
    }
    
    return(
        <>
            <form action="#">
                <div>
                    <input type="checkbox" id={id.state} />
                    <label htmlFor={id.state}>are you ok?</label>
                </div>
                <div>
                    <input type="checkbox" id={id.likes} />
                    <label htmlFor={id.likes}>do you use react?</label>
                </div>
            </form>
        </>
    )
}