import { useState, useEffect, useMemo } from 'react'
import './App.css'
export default function App() {

    const [value, setValue] = useState( ()=> 0)

    useEffect( ()=>{
        console.log('times')
    }, [value])

   //const otherValue = long(value)
    const otherValue = useMemo( ()=>{
        long(value)
    }, [value])
    function long(number) {
        for (let i = 0; i < 1000000000; i++) {}
        return number * 2
    }

    function increment() {
        setValue( oldValue => oldValue + 1)
    }

    const [numbers, setNumbers] = useState( ()=>  100)
    function increment2() {
        setNumbers(oldNUmber => oldNUmber + 10)
    }


    return(
        <>
         <h1>useMemo</h1>
         <hr /> 
         <p>normal: {value}</p>
         <p>out: {numbers}</p>
         <button onClick={increment}>increment</button>
         <button onClick={increment2}>increment out</button> 
        </>
    )
}