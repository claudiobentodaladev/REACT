import {createRoot} from 'react-dom/client'
import App from './App.js'

createRoot(window.document.querySelector('#root')).render(<App/>)