import {useReducer} from 'react'
import './App.css'
export default function App() {

    const [state, dispatch] = useReducer(reducer, {
        score1: 0,
        score2: 0
    })
    
    function reducer(state, action) {
        switch (action.type) {
            case 'player1':
                return{
                    score1: state.score1 + 1,
                    score2: state.score2
                }
                break;
            case 'player2':
                return{
                    score2: state.score2 + 1,
                    score1: state.score1
                }
                break; 
            case 'reset':
                return{
                    score2: 0,
                    score1: 0
                }
                break;
            default:
                return state
                break;
        }
    }

    function scorePlayer1() {
        dispatch({
            type: 'player1'
        })
    }
    function scorePlayer2() {
        dispatch({
            type: 'player2'
        })
    }
    function resetScore() {
        dispatch({
            type: 'reset'
        })
    }

    return(
        <>
            <h1>game</h1>
            <p>player 1: {state.score1}</p>
            <p>player 2: {state.score2 }</p>

            <button onClick={scorePlayer1}>player 1</button>
            <button onClick={scorePlayer2}>player 2</button>
            <button onClick={resetScore}>reset score</button>
        </>
    )
}