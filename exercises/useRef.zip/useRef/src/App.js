import {useState, useEffect,useRef, use} from "react"
import './App.css'

export default function App() {

    const [text, setText] = useState(()=> '')
    const inputRef = useRef()

    const times = useRef(0)
    useEffect( ()=>{
        times.current++ ; console.clear()
        console.log(times)
    })

{/*           OR
    if (times.current++) {
        console.clear()
    }

*/}

    function show() {
        inputRef.current.focus()
        console.log(inputRef.current.value)
    }

    const upText = text => setText( ()=> text )

    return(
        <>
            <h1>react hooks</h1>
            <hr />
            <input ref={inputRef} type="text" id="textBox" onChange={ event => upText(event.target.value) } />
            <hr />
            <p>text is <strong>"{text}"</strong></p>
            <button onClick={show}>click</button>
        </>
    )
}