import {useState} from "react"

export default function App() {

    function valuIn() {
        console.log('again!')
        return 500
    }
    
    const [value, setValue] = useState(()=> 3)

    function sam() {
        setValue(value - 1)
    }
    function sub() {
        setValue(value + 1)
    }

    return(
        <>
            <h1>react hooks</h1>
            <p>value : {value}</p>
            <div>
                <button onClick={sam}>sam</button>
                <button onClick={sub}>sub</button>
            </div>
        </>
    )
}